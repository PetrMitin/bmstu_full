# frozen_string_literal: true

require './part3'

# Цыпленок мышонок

puts 'Enter words separated by space'
output(gets)
