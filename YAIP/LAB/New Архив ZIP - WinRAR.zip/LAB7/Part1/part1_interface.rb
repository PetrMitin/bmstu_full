# frozen_string_literal: true

require './part1'

def output
  str, str_ans = write_symbols_after_a
  puts "Initial string: #{str}"
  puts "Result: #{str_ans}"
end

output
